package vincent.m3u8_downloader.loader;

public class LoaderInfoType {
    public static final int FILE = 0;
    public static final int M3U8_INFO = 1;
}
