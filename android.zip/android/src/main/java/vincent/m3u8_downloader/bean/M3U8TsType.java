package vincent.m3u8_downloader.bean;

public class M3U8TsType {
    public static final int TS = 0;
    public static final int KEY = 1;
}
